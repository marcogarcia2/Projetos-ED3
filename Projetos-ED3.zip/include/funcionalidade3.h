/*  
*   Lucas Lima Romero - 13676325
*   Marco Antonio Gaspar Garcia - 11833581
*/

#ifndef FUNCIONALIDADE_3_H
#define FUNCIONALIDADE_3_H

// Funcionalidade 3
void buscaPorCampo(char *nomeArquivoBIN, int n);
    
#endif
