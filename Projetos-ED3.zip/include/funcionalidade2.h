/*  
*   Lucas Lima Romero - 13676325
*   Marco Antonio Gaspar Garcia - 11833581
*/

#ifndef FUNCIONALIDADE_2_H
#define FUNCIONALIDADE_2_H

void recuperaDados(const char* nomeArquivoBIN);

#endif
