/*  
*   Lucas Lima Romero - 13676325
*   Marco Antonio Gaspar Garcia - 11833581
*/

#ifndef FUNCIONALIDADE_1_H
#define FUNCIONALIDADE_1_H

// Funcionalidade 1
void criaTabela(char *nomeArquivoCSV, char *nomeArquivoBIN);
    
#endif
