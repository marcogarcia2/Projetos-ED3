/*  
*   Lucas Lima Romero - 13676325
*   Marco Antonio Gaspar Garcia - 11833581
*/

#ifndef FUNCIONALIDADE_4_H
#define FUNCIONALIDADE_4_H

// Funcionalidade 4
void buscaPorRRN(char *nomeArquivoBIN, int RRN);
    
#endif
